﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomChordProgressionConsoleApplication2
{
    public enum Major
    {
        I,
        ii,
        iii,
        IV,
        V,
        vi,
        diminished_vii
    }
}
