﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomChordProgressionConsoleApplication2
{
    class Program
    {
        static void Main()
        {
            Progression progression1 = new Progression();

            Random random = new Random();

            int majorOrMinor = random.Next(0, 2);
            int chord1 = random.Next(0, 7);
            int chord2 = random.Next(0, 7);
            int chord3 = random.Next(0, 7);
            int chord4 = random.Next(0, 7);
            int pickKey = random.Next(0, 12);

            Console.WriteLine("Here is your random chord progression:");

            if (majorOrMinor == 0)
            {
                Console.WriteLine($"{progression1.Major[chord1]} chord, {progression1.Major[chord2]} chord, {progression1.Major[chord3]} chord, {progression1.Major[chord4]} chord.");
            }
            else
            {
                Console.WriteLine($"{progression1.Minor[chord1]} chord, {progression1.Minor[chord2]} chord, {progression1.Minor[chord3]} chord, {progression1.Minor[chord4]} chord.");
            }

            Console.WriteLine($"Play this progression in the key of {progression1.Key[pickKey]} {progression1.MajorMinor[majorOrMinor]}.");

            //Console.Write($"{majorOrMinor}");
            Console.Write("Hit enter.");
            Console.ReadLine();

        }
    }
}
