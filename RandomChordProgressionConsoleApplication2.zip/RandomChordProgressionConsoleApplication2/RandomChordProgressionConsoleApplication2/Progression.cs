﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomChordProgressionConsoleApplication2
{
    class Progression
    {
        public string[] Major = { "I", "ii", "iii", "IV", "V", "vi", "diminished vii" };
        public string[] Minor = { "i", "diminished ii", "III", "iv", "V", "VI", "VII or diminished vii" };
        public string[] Key = { "A", "A#/Bb", "B", "C", "C#/Db", "D", "D#/Eb", "E", "F", "F#/Gb", "G", "G#/Ab" };
        public string[] MajorMinor = { "Major", "Minor" };
        //public string[] FourChordProgression;

    }
}
